import csv
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import shutil

shutil.rmtree(matplotlib.get_cachedir())
# from matplotlib.font_manager import _rebuild
# _rebuild() #reload一下
# -*- coding: utf-8 -*-
all=[]

for filename in ['随申码valid.csv','苏康码valid.csv','北京健康宝valid.csv','粤康码valid.csv','西安一码通valid.csv']:
    with open(filename,'r', encoding='utf-8') as fin:
        reader = csv.reader(fin)
        l = []
        for line in reader:
            l.append(line)
        all.append(l)

t1 = [33,34,35,36,37,38]
title_t1 = ['您对健康码展示页面各类颜色代表情形非常了解',
            '您对健康码各颜色所需做出的相应行为非常了解',
            '健康码保障了您和他人的安全',
            '健康码在疫情防控中发挥了重要作用',
            '健康码打开速度较快',
            '登录时身份认证方便（验证是否为本人操作）']
gap_1 =[63, 53, 52, 61]

t2 = [73,74,75,76,77]
t3 = [79,80,81]
t4 = [83]
gap_2 = [63,44,60,45]

for t,title  in zip(t1,title_t1):
    t_5_code = [t]
    for add in gap_1:
        t_5_code.append(t_5_code[-1] + add)
    l_p = []
    for code in range(5):
        t_this = t_5_code[code]
        ans_count_list = []
        ans_count = {'A.非常符合': 0,'B.比较符合': 0, 'C.难以判断': 0, 'D.不太符合': 0,'E.非常不符合': 0}
        for line in all[code][1:]:
            ans_count[line[t_this]] = ans_count[line[t_this]] + 1
        for key in ['A.非常符合','B.比较符合', 'C.难以判断', 'D.不太符合','E.非常不符合']:
            ans_count_list.append(ans_count[key])
        sum1 = sum(ans_count_list)
        percentage = [x*1.0/sum1 for x in ans_count_list]
        l_p.append(percentage)
    x = ['随申码', '苏康码','北京健康宝','粤康码','西安一码通']
    y = np.array(l_p).transpose()
    plt.title(title)
    plt.bar(x, y[0], label='非常符合',fc = 'tab:green', width = 0.5)
    plt.bar(x, y[1], bottom=y[0], label='比较符合',fc = 'tab:olive', width = 0.5)
    plt.bar(x, y[2], bottom=y[0]+y[1], label='难以判断',fc = 'tab:gray', width = 0.5)
    plt.bar(x, y[3], bottom=y[0]+y[1]+y[2], label='不太符合',fc = 'tab:pink', width = 0.5)
    plt.bar(x, y[4], bottom=y[0]+y[1]+y[2]+y[3], label='非常不符合',fc = 'tab:red', width = 0.5)
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05),  fancybox=True, ncol=5)
    plt.rcParams['font.sans-serif']=['SimHei']
    plt.savefig(title)
    # plt.show()


#
# name = all[0][0]
# for i,item in enumerate(name):
#     print(i,item) # 0开始

# t33 = []
# for li in l:
#     t33.append(li[33])
# t33 = t33[1:]
# print(t33)
# t33d = {'A.非常符合': 0,'B.比较符合': 0, 'C.难以判断': 0, 'D.不太符合': 0,'E.非常不符合': 0}
# for key in t33:
#     t33d[key] = t33d.get(key, 0) + 1
# print(t33d)
#
#
# t96 = []
# for li in l1:
#     t96.append(li[96])
# t96 = t96[1:]
# t96d = {'A.非常符合': 0,'B.比较符合': 0, 'C.难以判断': 0, 'D.不太符合': 0,'E.非常不符合': 0}
# for key in t96:
#     t96d[key] = t96d.get(key, 0) + 1
# print(t96d)
#
#
#
# x = ['随申码', '苏康码']
# a = np.array([91,23]) # 非常同意
# b = np.array([43,10])
# c = np.array([50,10])
# d = np.array([25,15])
# e = np.array([10,20])
# plt.bar(x, a, label='非常符合',fc = 'r')
# plt.bar(x, b, bottom=a, label='比较符合',fc = 'g')
# plt.bar(x, c, bottom=a+b, label='难以判断',fc = 'b')
# plt.bar(x, d, bottom=a+b+c, label='比较不符合',fc = 'c')
# plt.bar(x, e, bottom=a+b+c+d, label='非常不符合',fc = 'm')
# plt.legend()
# plt.show()

# 随申码
# 33 34 35 36 37 38 非常符合 比较符合 难以判断 比较不符合 非常不符合
# 73 74 75 76 77 非常符合 比较符合 难以判断 比较不符合 非常不符合
# 79 80 81 没有遇到 偶尔 一般 经常
# 83 不可能崩溃 崩溃可能性低 崩溃可能性一般 崩溃可能性高 肯定会崩溃
# g 63 63
# 苏康码
# 96 97 98 99 100 101
# 136 137 138 139 140
# 142 143 144
# 146
# g 63 44
# 北京健康宝
# 149 150 151 152 153 154
# 180 181 182 183 184
# 186 187 188
# 190
# g 52 60
# 粤康码
# 201 202 203 204 205 206
# 240 241 242 243 244
# 246 247 248
# 250
# g 61 45
# 西安一码通
# 262 263 264 265 266 267
# 285 286 287 288 289
# 291 292 293
# 295
